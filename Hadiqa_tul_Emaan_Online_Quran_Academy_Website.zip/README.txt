Hadiqa tul Emaan Online Quran Academy Website

How to use:
1. Keep index.html and logo.png in the same folder.
2. Open index.html in a browser to preview the website.
3. Upload both files to any web hosting service to publish it online.
4. All WhatsApp, YouTube and Instagram buttons are clickable.

Note: WhatsApp opens a chat with +92 348 5175651. YouTube and Instagram open the handles provided by the academy.
